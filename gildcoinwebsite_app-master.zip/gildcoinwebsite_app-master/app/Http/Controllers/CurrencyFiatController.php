<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CurrencyFiatController extends Controller
{
    //
}
