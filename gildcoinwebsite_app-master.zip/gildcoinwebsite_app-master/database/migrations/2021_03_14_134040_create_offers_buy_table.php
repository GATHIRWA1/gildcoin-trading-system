<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOffersBuyTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('offers_buy', function (Blueprint $table) {
            
            // primary key
            $table->id();

            // foreign keys
            $table->unsignedBigInteger('user_id');
            $table->unsignedBiginteger('payment_method_id');
            $table->unsignedBigInteger('currency_crypto_id');

            // foreign key constraints 
            $table->foreign('user_id')->references('id')->on('users')->onUpdate('cascade');
            $table->foreign('payment_method_id')->references('id')->on('payment_methods')->onUpdate('cascade');
            $table->foreign('currency_crypto_id')->references('id')->on('currencies_crypto')->onUpdate('cascade');

            // columns
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('offers_buy');
    }
}
