<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOfferSellTagsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('offer_sell_tags', function (Blueprint $table) {
            
            // primary key
            $table->id();

            // foreign keys
            $table->unsignedBigInteger('offer_sell_id');
            $table->unsignedBigInteger('offer_tag_id');

            // foreign key constraints
            $table->foreign('offer_sell_id')->references('id')->on('offers_sell')->onUpdate('cascade');
            $table->foreign('offer_tag_id')->references('id')->on('offer_tags')->onUpdate('cascade');

            // columns
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('offer_sell_tags');
    }
}
