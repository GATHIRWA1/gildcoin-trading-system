<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCurrenciesFiatTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('currencies_fiat', function (Blueprint $table) {
            
            // primary key 
            $table->id();

            // foreign keys
            $table->unsignedBigInteger('country_id');

            // foreign key constraints
            $table->foreign('country_id')->references('id')->on('countries')->onUpdate('cascade');

            // columns
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('currencies_fiat');
    }
}
