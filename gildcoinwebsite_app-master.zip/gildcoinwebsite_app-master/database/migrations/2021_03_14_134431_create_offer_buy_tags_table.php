<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOfferBuyTagsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('offer_buy_tags', function (Blueprint $table) {
            
            // primary key
            $table->id();

            // foreign keys
            $table->unsignedBigInteger('offer_buy_id');
            $table->unsignedBigInteger('offer_tag_id');

            // foreing key constraints
            $table->foreign('offer_buy_id')->references('id')->on('offers_buy')->onUpdate('cascade');
            $table->foreign('offer_tag_id')->references('id')->on('offer_tags')->onUpdate('cascade');

            // columns
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('offer_buy_tags');
    }
}
