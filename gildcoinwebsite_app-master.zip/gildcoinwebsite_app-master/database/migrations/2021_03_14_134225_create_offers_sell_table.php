<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOffersSellTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('offers_sell', function (Blueprint $table) {
            
            // primary key
            $table->id();

            // foreign keys
            $table->unsignedBigInteger('currency_crypto_id');
            $table->unsignedBigInteger('user_id');
            $table->unsignedBigInteger('payment_method_id');

            // foreign key constraints
            $table->foreign('currency_crypto_id')->references('id')->on('currencies_crypto')->onUpdate('cascade');
            $table->foreign('user_id')->references('id')->on('users')->onUpdate('cascade');
            $table->foreign('payment_method_id')->references('id')->on('payment_methods')->onUpdate('cascade');

            // columns
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('offers_sell');
    }
}
