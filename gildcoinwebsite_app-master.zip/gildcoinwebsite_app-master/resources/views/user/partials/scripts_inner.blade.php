<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="user_inner/assets/js/jquery.min.js"></script>
<script src="user_inner/assets/js/popper.min.js"></script>
<script src="user_inner/assets/js/bootstrap.min.js"></script>

<!-- General site JS file -->
<script src="user_inner/assets/js/site.js"></script>