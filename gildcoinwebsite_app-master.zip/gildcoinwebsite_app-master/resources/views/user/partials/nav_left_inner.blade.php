<ul class="nav nav_left flex-column text-center">
                        
    <li class="nav-item">
        <a href="dashboard" class="nav-link {{ Request::path() === 'dashboard' ? 'active' : '' }}">
            <h4><i class="fal fa-tachometer-alt-slow"></i></h4>
            <span>Dashboard</span>
        </a>
    </li>
    <!-- /li -->

    <li class="nav-item">
        <a href="trade_room" class="nav-link {{ Request::path() === 'trade_room' ? 'active' : ''}}">
            <h4><i class="fal fa-briefcase"></i></h4>
            <span>Trade Room</span>
        </a>
    </li>
    <!-- /li -->

    <li class="nav-item">
        <a href="historical_prices" class="nav-link {{ Request::path() === 'historical_prices' ? 'active' : '' }}">
            <h4><i class="fal fa-chart-bar"></i></h4>
            <span>Historical Prices</span>
        </a>
    </li>
    <!-- /li -->

    <li class="nav-item">
        <a href="trading_history" class="nav-link {{ Request::path() === 'trading_history' ? 'active' : '' }}">
            <h4><i class="fal fa-history"></i></h4>
            <span>Trading History</span>
        </a>
    </li>
    <!-- /li -->

    <li class="nav-item">
        <a href="wallet" class="nav-link {{ Request::path() === 'wallet' ? 'active' : '' }}">
            <h4><i class="far fa-wallet"></i></h4>
            <span>My Wallet</span>
        </a>
    </li>
    <!-- /li -->

    <li class="nav-item">
        <a href="#none" data-bs-toggle="modal" data-bs-target="#leaderBoardModal" class="nav-link">
            <h4><i class="fal fa-award"></i></h4>
            <span>Leader Board</span>
        </a>
    </li>
    <!-- /li -->

</ul>