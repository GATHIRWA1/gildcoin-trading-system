<img src="user_outer/assets/img/logos/gildcoin_logo.svg" alt="" style="height: 40px;">
