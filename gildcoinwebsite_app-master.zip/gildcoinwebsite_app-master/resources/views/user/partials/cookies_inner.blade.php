<div class="toast toast_cookies d-flex" role="alert" aria-live="assertive" aria-atomic="true" data-bs-autohide="false">
                    
    <div class="toast-body">
        We use cookies to understand how you use our site and to improve your experience. By continuing to use our website you agree to their use. <a href="#none">More info</a>
    </div>
    
    <button type="button" class="btn-close ms-auto me-2 mt-2" data-bs-dismiss="toast" aria-label="Close"></button>

</div>                
<!-- /toast -->