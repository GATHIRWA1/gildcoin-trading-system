<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="user_outer/assets/js/jquery.min.js"></script>
<script src="user_outer/assets/js/popper.min.js"></script>
<script src="user_outer/assets/js/bootstrap.min.js"></script>

<script>
    
    $(document).ready(function() {
        $(".toast").toast("show")
    })

</script>