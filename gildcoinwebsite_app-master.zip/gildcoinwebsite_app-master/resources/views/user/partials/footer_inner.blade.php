<nav class="navbar navbar_bottom fixed-bottom navbar-dark bg-dark text-light">
            
    <div class="container-fluid">
        
        <div class="row">
            
            <div class="col-6">
                <i class="far fa-clock"></i> Current Time: <span class="timeInsert">12:23:43</span> • 14 January, 2020 (GMT +3)
            </div>
            <!-- /col -->

            <div class="col-6 text-end">
                <a href="#none" class="btn btn-outline-secondary btn-sm"><i class="far fa-user-friends"></i> Partnerships</a>

                <a href="#none" class="btn btn-primary btn-sm"><i class="far fa-comments"></i> Support</a>
            </div>
            <!-- /col -->
        </div>
        <!-- /row -->
    </div>
    <!-- /container-fluid -->

</nav>
<!-- /nav -->