@extends('user/layouts/layout_inner')

@section('title', 'Wallet')

@section('content')

	<div class="col-md-11">

	    <div class="card card_wallet bg-dark mt-0">
	        
	        <div class="card-header">

	            <h5 class="my-2">My Wallet</h5>

	        </div>
	        <!-- /card-header -->

	        <div class="card-body">
	            
	            <div class="row row_wallet g-0">
	                
	                <div class="col-md-2">
	                    
	                    <ul class="nav nav_wallet flex-column">
	                
	                        <li class="nav-item">

	                            <a href="wallet" class="nav-link active">
	                                <h3><i class="fal fa-money-bill"></i></h3>
	                                <h5>Cash</h5>
	                            </a>
	                        </li>

	                        <li class="nav-item">
	                            <a href="wallet_crypto" class="nav-link">
	                                <h3><i class="fal fa-coin"></i></h3>
	                                <h5>Crypto</h5>
	                            </a>
	                        </li>
	                    </ul>
	                    <!-- /nav_wallet -->

	                </div>
	                <!-- /col -->

	                <div class="col-md-10 p-3">
	                    
	                    <a href="#none" data-bs-toggle="modal" data-bs-target="#depositModal" class="btn btn-outline-success"><i class="fas fa-arrow-down"></i> Deposit Cash</a>

	                    <a href="#none" class="btn btn-outline-secondary">Withdraw Cash <i class="fas fa-arrow-up"></i></a>

	                </div>
	                <!-- /col -->
	            </div>
	            <!-- /row -->
	        </div>
	        <!-- /card-body -->
	    </div>
	    <!-- /card -->

	</div>
	<!-- /right_col -->

@endsection