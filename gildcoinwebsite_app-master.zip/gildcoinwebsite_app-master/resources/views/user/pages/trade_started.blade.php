@extends('user/layouts/layout_inner')

@section('title', 'Trade')

@section('content')

	<div class="col-md-11">
                    
        <div class="row">
            
            <div class="col-md-6 pt-3">
        
                <h3 class="mb-3">
                    <i class="fas fa-circle me-2 text-danger"></i> Trade Started
                </h3>

                <div class="alert alert-dark alert-dismissible fade show" role="alert">
                    
                    <i class="fas fa-exclamation-triangle text-danger"></i> It is not safe to trade or exchange information with your trade partner outside Gildcoin. Our moderators will not be able to help you resolve any issues in such case.

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <!-- /alert -->

                <div class="card card_trade bg-dark mb-3">
                    
                    <div class="card-header py-3">
                        
                        <div class="d-flex align-items-center">
                            <h3 class="me-3">
                                <i class="fal fa-clock"></i>
                            </h3>
                            <div>
                                <h5>Please make a payment of 10,000 KES using M-Pesa.</h5>
                                <p class="m-0">0.000034323 Gildcoin will be added to your wallet.</p>
                            </div>
                        </div>

                    </div>
                    <!-- /card-header -->

                    <div class="card-body">
                        
                        <p class="fs-5"><strong>Once you've made the payment</strong>, be sure to click Paid within the given limit. Otherwise the trade will be automatically canceled and the Gildcoin will be returned to the seller's wallet.</p>

                        <div class="d-flex align-items-center">
                            <a href="#none" class="btn btn-success me-3 px-3">Paid</a>
                            <p class="m-0 text-muted">Time left 00:29:30</p>
                        </div>

                    </div>
                    <!-- /card-body -->
                    
                    <div class="card-footer">
                        <div class="d-flex align-items-center justify-content-between">
                            
                            <a href="#none" data-bs-toggle="modal" data-bs-target="#cancelTradeModal" class="btn btn-outline-danger">
                                <i class="fas fa-times"></i> Cancel Trade
                            </a>
                            
                            <p class="m-0 text-muted">
                                <i class="fal fa-exclamation-circle"></i> You haven't paid yet
                            </p>
                        </div>
                    </div>
                    <!-- /card-footer -->
                </div>
                <!-- /card_trade -->

                <h5>Please follow user345's instructions:</h5>

                <div class="trade_badges mb-3">
                    <span class="badge">no receipt needed</span>
                    <span class="badge">no verification needed</span>
                    <span class="badge">online payments</span>
                </div>

                <div class="trade_instructions">
                    
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Tenetur itaque praesentium magnam soluta earum eveniet, rerum eos doloribus nisi culpa, laudantium, nostrum quis ab minima obcaecati dolorum doloremque molestiae aspernatur?</p>

                    <p>Lorem ipsum dolor sit, amet, consectetur adipisicing elit. Non aspernatur, fugit in illo facere, minus neque suscipit quam, nostrum earum, consequuntur repellat! Beatae est, commodi minus vel aspernatur modi quisquam?</p>
                </div>

                <h5>Trade Information:</h5>

                <p>0.00001 GTC has been reserved for this trade. This includes our fee of 0.00001 GTC</p>

                <div class="row row_trade_info">
                    <div class="col">
                        <h6>RATE</h6>
                        <p class="m-0">100.00 KES/GTC</p>
                    </div>
                    <!-- /col -->

                    <div class="col">
                        <h6>TRADE ID</h6>
                        <p class="m-0">thwrew5734mRWd631</p>
                    </div>
                    <!-- /col -->

                    <div class="col">
                        <h6>STARTED</h6>
                        <p class="m-0">a few seconds ago</p>
                    </div>
                    <!-- /col -->
                </div>
                <!-- /row -->
            </div>
            <!-- /col -->

            <div class="col-md-6 pt-3">

                <div class="card card_chat bg-dark mt-0">
                    
                    <div class="card-header">
                        
                        <div class="row">
                            
                            <div class="col-6 align-items-center d-flex">
                                
                                <a href="user">
                                    <div class="img me-2" style="background-image: url(user_inner/assets/img/profile2.jpg);"></div>
                                </a>

                                <a href="user" class="text-decoration-none me-2">
                                    <h6 class="m-0">DonaldTrump</h6>
                                </a>

                                <span class="text-muted">
                                    <small>
                                        <i class="fas fa-circle text-muted"></i>
                                        Seen 3 mins ago
                                    </small>
                                </span>
                            </div>
                            <!-- /col -->

                            <div class="col-6 align-items-center text-end">
                                <a href="#none" class="btn btn-sm btn-outline-success">
                                    <i class="fas fa-thumbs-up"></i> 100
                                </a>

                                <a href="#none" class="btn btn-sm btn-outline-danger">
                                    <i class="fas fa-thumbs-down"></i> 0
                                </a>
                            </div>
                            <!-- /col -->
                        </div>
                        <!-- /row -->

                    </div>
                    <!-- /card-header -->

                    <a href="#none" class="text-decoration-none">
                        <div class="moderator p-2 px-3">
                            <i class="fas fa-circle me-1 text-success"></i> Moderator available
                        </div>
                    </a>

                    <div class="card-body">

                        <div class="row row_outgoing">
                            <div class="col-1">
                                
                                <a href="user">
                                    <div class="img online" style="background-image: url(user_inner/assets/img/profile.jpg);"></div>
                                </a>

                            </div>
                            <!-- /col -->

                            <div class="col-11">
                                
                                <div class="message">
                                    
                                    <p>Hi there Donald Trump.</p>

                                    <span class="time">March 2, 2021, 06:08 am</span>
                                </div>
                                

                            </div>
                            <!-- /col -->
                        </div>
                        <!-- /row -->

                        <div class="row row_incoming">
                            <div class="col-1">
                                
                                <a href="user">
                                    <div class="img" style="background-image: url(user_inner/assets/img/profile2.jpg);"></div>
                                </a>
                            
                            </div>
                            <!-- /col -->

                            <div class="col-11">
                                
                                <div class="message">
                                    
                                    <p>Hi there Barack, how're you holding up?</p>

                                    <span class="time">March 2, 2021, 06:08 am</span>

                                </div>
                                
                            </div>
                            <!-- /col -->
                        </div>
                        <!-- /row -->

                        <div class="row row_outgoing">
                            <div class="col-1">
                                
                                <a href="user">
                                    <div class="img online" style="background-image: url(user_inner/assets/img/profile.jpg);"></div>
                                </a>

                            </div>
                            <!-- /col -->

                            <div class="col-11">
                                
                                <div class="message">
                                    
                                    <p>Much better than you, consectetur adipisicing elit. Repudiandae magni nam explicabo et ipsam exercitationem, dignissimos excepturi dolorum aut, fugiat amet rem nihil quod, vitae vero esse ducimus libero quasi.</p>

                                    <span class="time">March 2, 2021, 06:08 am</span>

                                </div>
                                
                            </div>
                            <!-- /col -->
                        </div>
                        <!-- /row -->

                        <div class="row row_incoming">
                            <div class="col-1">
                                
                                <a href="user">
                                    <div class="img" style="background-image: url(user_inner/assets/img/profile2.jpg);"></div>
                                </a>
                            
                            </div>
                            <!-- /col -->

                            <div class="col-11">
                                
                                <div class="message">
                                    
                                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Repudiandae magni nam explicabo et ipsam exercitationem, dignissimos excepturi dolorum aut, fugiat amet rem nihil quod, vitae vero esse ducimus libero quasi.</p>

                                    <span class="time">March 2, 2021, 06:08 am</span>

                                </div>
                                
                            </div>
                            <!-- /col -->
                        </div>
                        <!-- /row -->

                        <div class="row row_outgoing">
                            <div class="col-1">
                                
                                <a href="user">
                                    <div class="img online" style="background-image: url(user_inner/assets/img/profile.jpg);"></div>
                                </a>

                            </div>
                            <!-- /col -->

                            <div class="col-11">
                                
                                <div class="message">
                                    
                                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Repudiandae magni nam explicabo et ipsam exercitationem, dignissimos excepturi dolorum aut, fugiat amet rem nihil quod, vitae vero esse ducimus libero quasi.</p>

                                    <span class="time">March 2, 2021, 06:08 am</span>

                                </div>
                                
                            </div>
                            <!-- /col -->
                        </div>
                        <!-- /row -->
                        
                    </div>
                    <!-- /card-body -->

                    <div class="card-footer py-3">
                        
                        <form action="">
                            
                            <div class="input-group">

                                <a href="#none" class="btn btn-outline-secondary py-3">
                                    <i class="fal fa-paperclip"></i>
                                </a>
                                
                                <input type="text" class="form-control py-3 text-light" name="message" placeholder="Write message..." required="required">

                                <button class="btn btn-outline-secondary py-3" type="submit" name="send">
                                    <i class="fal fa-paper-plane"></i> Send
                                </button>

                            </div>
                    
                        </form>

                    </div>
                    <!-- /card-footer -->
                </div>
                <!-- /card -->

            </div>
            <!-- /col -->

        </div>
        <!-- /row -->
    </div>
    <!-- /right col -->

@endsection

@include('user/modals/cancel_trade')