@extends('user/layouts/layout_inner')

@section('title', 'Buy Cryptocurrency')

@section('content')

    <div class="col-md-11">

        <div class="card card_buy_sell bg-dark mt-0">
            
            <div class="card-header d-flex align-items-center">
                
                <div class="img img_title me-2" style="background-image: url(user_inner/assets/img/icon.png);"></div>

                <h3 class="my-2">Buy Gildcoin <span class="text-muted">(GLC)</span></h3>

                <div class="ms-auto d-flex align-items-center">

                    <div class="form-check form-switch me-3">
                        <input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault">
                        <label class="form-check-label" for="flexSwitchCheckDefault">Trusted offers only</label>
                    </div>
                   
                </div>
                <!-- /ms-auto -->

            </div>
            <!-- /card-header -->

            <div class="card-body">
                
                <div class="row row_buy_sell">

                    <div class="col-md-2">

                        <form action="" method="get">
                            
                            <div class="search_offers">
                            
                                <h6>Cryptocurrency</h6>

                                <select name="crypto_currency" class="form-select mb-2">
                                    <option value="">Gildcoin</option>
                                    <option value="">Bitcoin</option>
                                </select>

                                <p><i class="fal fa-info-circle text-muted"></i> 1 GLC = 109.35 KES</p>

                                <h6>Payment Method</h6>

                                <select name="payment_method" class="form-select mb-3">
                                    <option value="">Any</option>
                                    <option value="">M-pesa</option>
                                    <option value="">Visa</option>
                                </select>

                                <h6>Amount</h6>

                                <div class="input-group input-group-currency mb-3">
                                    <input name="amount" type="number" placeholder="Any" class="form-control">
                                    
                                    <select name="currency" class="form-select">
                                        <option value="">KES</option>
                                        <option value="">USD</option>
                                        <option value="">EUR</option>
                                    </select>
                                </div>

                                <h6>Trade Limits (KES)</h6>

                                <div class="row g-1 mb-3">
                                    <div class="col">
                                        <input type="number" name="min" class="form-control" placeholder="Min">
                                    </div>

                                    <div class="col">
                                        <input type="number" name="max" class="form-control" placeholder="Max">
                                    </div>
                                </div>

                                <div class="d-grid">
                                    <button type="submit" class="btn btn-primary"><i class="fal fa-search"></i> Show Offers</button>
                                </div>

                            </div>
                            <!-- /search_offers -->

                        </form>
                        
                    </div>
                    <!-- /left -->

                    <div class="col-md-10">
                        
                        <table class="table table-hover table_buy text-light">
                            <thead>
                                <tr>
                                    <th>Buy From</th>
                                    <th style="width: 16%;">Get Paid With</th>
                                    <th style="width: 11%;">Time Posted</th>
                                    <th style="width: 15%;">
                                        Trade Limits

                                        <a href="#none" class="text-muted">
                                            <i class="far fa-info-circle" title="The maximum and minimum amount worth of gildcoin on offer"></i>
                                        </a>
                                    </th>
                                    <th style="width: 11%;">
                                        
                                        Difference 

                                        <a href="#none" class="text-muted">
                                            <i class="far fa-info-circle" title="The seller has quoted a price +5.50% above the current market price"></i>
                                        </a>
                                    </th>
                                    <th style="width: 18%;">
                                        
                                        Price per Gildcoin
                                        
                                        <a href="#none" class="text-muted">
                                            <i class="far fa-info-circle" title="xxx"></i>
                                        </a> 

                                    </th>
                                    <th style="width: 1%;">
                                        
                                        <a href="#none" class="btn btn-sm btn-outline-secondary" title="xxx">
                                            <i class="fal fa-sort-amount-down-alt"></i>
                                        </a>

                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                
                                <tr>
                                    <td>
                                        <h6>
                                            <i class="fal fa-user text-muted"></i> 
                                            <a href="user">BarackObama</a>
                                        </h6>
                                    </td>
                                    <td>
                                        <h6>M-Pesa</h6>
                                    </td>
                                    <td>
                                        1 hour ago
                                    </td>
                                    <td>
                                        100,200 - 200,000 <span class="text-muted">KES</span>
                                    </td>
                                    <td>
                                        <p class="m-0">
                                            <span class="me-2">
                                                
                                                <i class="fas fa-arrow-up text-muted"></i> 
                                                
                                                +5.50%

                                                
                                            </span>

                                        </p>
                                    </td>
                                    <td>
                                        <h5>9,107,193.83 <span class="text-muted">KES</span></h5>
                                        
                                    </td>
                                    <td>
                                        <a href="trade_buy" class="btn btn-sm btn-outline-primary">
                                            <span>BUY</span>
                                            <div class="img" style="background-image: url(user_inner/assets/img/icon.png);"></div>
                                        </a>
                                    </td>
                                </tr>

                                <tr>
                                    <td>
                                        <h6>
                                            <i class="fal fa-user text-muted"></i> 
                                            <a href="user">ForexTrader1</a>
                                        </h6>
                                    </td>
                                    <td>
                                        <h6>M-Pesa</h6>
                                    </td>
                                    <td>
                                        1 hour ago
                                    </td>
                                    <td>
                                        1,200 - 2,000 <span class="text-muted">KES</span>
                                    </td>
                                    <td>
                                        <p class="m-0">
                                            <span class="me-2">
                                                
                                                <i class="fas fa-arrow-up text-muted"></i> 
                                                
                                                +5.50%

                                                
                                            </span>

                                        </p>
                                    </td>
                                    <td>
                                        <h5>193.83 <span class="text-muted">KES</span></h5>
                                        
                                    </td>
                                    <td>
                                        <a href="trade_buy" class="btn btn-sm btn-outline-primary">
                                            <span>BUY</span>
                                            <div class="img" style="background-image: url(user_inner/assets/img/icon.png);"></div>
                                        </a>
                                    </td>
                                </tr>

                                <tr>
                                    <td>
                                        <h6>
                                            <i class="fal fa-user text-muted"></i> 
                                            <a href="user">ForexTrader1</a>
                                        </h6>
                                    </td>
                                    <td>
                                        <h6>Airtel money</h6>
                                    </td>
                                    <td>
                                        1 hour ago
                                    </td>
                                    <td>
                                        1,200 - 2,000 <span class="text-muted">KES</span>
                                    </td>
                                    <td>
                                        <p class="m-0">
                                            <span class="me-2">
                                                
                                                <i class="fas fa-arrow-up text-muted"></i> 
                                                
                                                +15.50%

                                                
                                            </span>

                                        </p>
                                    </td>
                                    <td>
                                        <h5>9,107,193.83 <span class="text-muted">KES</span></h5>
                                        
                                    </td>
                                    <td>
                                        <a href="trade_buy" class="btn btn-sm btn-outline-primary">
                                            <span>BUY</span>
                                            <div class="img" style="background-image: url(user_inner/assets/img/icon.png);"></div>
                                        </a>
                                    </td>
                                </tr>

                                <tr>
                                    <td>
                                        <h6>
                                            <i class="fal fa-user text-muted"></i> 
                                            <a href="user">ForexTrader1</a>
                                        </h6>
                                    </td>
                                    <td>
                                        <h6>Bank Transfer</h6>
                                    </td>
                                    <td>
                                        1 hour ago
                                    </td>
                                    <td>
                                        1,200 - 2,000 <span class="text-muted">KES</span>
                                    </td>
                                    <td>
                                        <p class="m-0">
                                            <span class="me-2">
                                                
                                                <i class="fas fa-arrow-up text-muted"></i> 
                                                
                                                +5.50%

                                                
                                            </span>

                                        </p>
                                    </td>
                                    <td>
                                        <h5>9,107,193.83 <span class="text-muted">KES</span></h5>
                                        
                                    </td>
                                    <td>
                                        <a href="trade_buy" class="btn btn-sm btn-outline-primary">
                                            <span>BUY</span>
                                            <div class="img" style="background-image: url(user_inner/assets/img/icon.png);"></div>
                                        </a>
                                    </td>
                                </tr>

                                <tr>
                                    <td>
                                        <h6>
                                            <i class="fal fa-user text-muted"></i> 
                                            <a href="user">ForexTrader1</a>
                                        </h6>
                                    </td>
                                    <td>
                                        <h6>Visa</h6>
                                    </td>
                                    <td>
                                        1 hour ago
                                    </td>
                                    <td>
                                        1,200 - 2,000 <span class="text-muted">KES</span>
                                    </td>
                                    <td>
                                        <p class="m-0">
                                            <span class="me-2">
                                                
                                                <i class="fas fa-arrow-up text-muted"></i> 
                                                
                                                +5.50%

                                                
                                            </span>

                                        </p>
                                    </td>
                                    <td>
                                        <h5>9,107,193.83 <span class="text-muted">KES</span></h5>
                                        
                                    </td>
                                    <td>
                                        <a href="trade_buy" class="btn btn-sm btn-outline-primary">
                                            <span>BUY</span>
                                            <div class="img" style="background-image: url(user_inner/assets/img/icon.png);"></div>
                                        </a>
                                    </td>
                                </tr>

                                <tr>
                                    <td>
                                        <h6>
                                            <i class="fal fa-user text-muted"></i> 
                                            <a href="user">ForexTrader1</a>
                                        </h6>
                                    </td>
                                    <td>
                                        <h6>Paypal</h6>
                                    </td>
                                    <td>
                                        1 hour ago
                                    </td>
                                    <td>
                                        1,200 - 2,000 <span class="text-muted">KES</span>
                                    </td>
                                    <td>
                                        <p class="m-0">
                                            <span class="me-2">
                                                
                                                <i class="fas fa-arrow-up text-muted"></i> 
                                                
                                                +5.50%

                                                
                                            </span>

                                        </p>
                                    </td>
                                    <td>
                                        <h5>9,107,193.83 <span class="text-muted">KES</span></h5>
                                        
                                    </td>
                                    <td>
                                        <a href="trade_buy" class="btn btn-sm btn-outline-primary">
                                            <span>BUY</span>
                                            <div class="img" style="background-image: url(user_inner/assets/img/icon.png);"></div>
                                        </a>
                                    </td>
                                </tr>

                                <tr>
                                    <td>
                                        <h6>
                                            <i class="fal fa-user text-muted"></i> 
                                            <a href="user">KamalaHaris234</a>
                                        </h6>
                                    </td>
                                    <td>
                                        <h6>MTN Mobile Money</h6>
                                    </td>
                                    <td>
                                        1 hour ago
                                    </td>
                                    <td>
                                        1,200 - 2,000 <span class="text-muted">KES</span>
                                    </td>
                                    <td>
                                        <p class="m-0">
                                            <span class="me-2">
                                                
                                                <i class="fas fa-arrow-up text-muted"></i> 
                                                
                                                +5.50%

                                                
                                            </span>

                                        </p>
                                    </td>
                                    <td>
                                        <h5>9,107,193.83 <span class="text-muted">KES</span></h5>
                                        
                                    </td>
                                    <td>
                                        <a href="trade_buy" class="btn btn-sm btn-outline-primary">
                                            <span>BUY</span>
                                            <div class="img" style="background-image: url(user_inner/assets/img/icon.png);"></div>
                                        </a>
                                    </td>
                                </tr>

                                <tr>
                                    <td>
                                        <h6>
                                            <i class="fal fa-user text-muted"></i> 
                                            <a href="user">ForexTrader1</a>
                                        </h6>
                                    </td>
                                    <td>
                                        <h6>Chipper Cash</h6>
                                    </td>
                                    <td>
                                        1 hour ago
                                    </td>
                                    <td>
                                        1,200 - 2,000 <span class="text-muted">KES</span>
                                    </td>
                                    <td>
                                        <p class="m-0">
                                            <span class="me-2">
                                                
                                                <i class="fas fa-arrow-up text-muted"></i> 
                                                
                                                +5.50%

                                                
                                            </span>

                                        </p>
                                    </td>
                                    <td>
                                        <h5>9,107,193.83 <span class="text-muted">KES</span></h5>
                                        
                                    </td>
                                    <td>
                                        <a href="trade_buy" class="btn btn-sm btn-outline-primary">
                                            <span>BUY</span>
                                            <div class="img" style="background-image: url(user_inner/assets/img/icon.png);"></div>
                                        </a>
                                    </td>
                                </tr>

                                <tr>
                                    <td>
                                        <h6>
                                            <i class="fal fa-user text-muted"></i> 
                                            <a href="user">ForexTrader1</a>
                                        </h6>
                                    </td>
                                    <td>
                                        <h6>M-Pesa</h6>
                                    </td>
                                    <td>
                                        1 hour ago
                                    </td>
                                    <td>
                                        1,200 - 2,000 <span class="text-muted">KES</span>
                                    </td>
                                    <td>
                                        <p class="m-0">
                                            <span class="me-2">
                                                
                                                <i class="fas fa-arrow-up text-muted"></i> 
                                                
                                                +5.50%

                                                
                                            </span>

                                        </p>
                                    </td>
                                    <td>
                                        <h5>9,107,193.83 <span class="text-muted">KES</span></h5>
                                        
                                    </td>
                                    <td>
                                        <a href="trade_buy" class="btn btn-sm btn-outline-primary">
                                            <span>BUY</span>
                                            <div class="img" style="background-image: url(user_inner/assets/img/icon.png);"></div>
                                        </a>
                                    </td>
                                </tr>

                                <tr>
                                    <td>
                                        <h6>
                                            <i class="fal fa-user text-muted"></i> 
                                            <a href="user">ForexTrader1</a>
                                        </h6>
                                    </td>
                                    <td>
                                        <h6>M-Pesa</h6>
                                    </td>
                                    <td>
                                        1 hour ago
                                    </td>
                                    <td>
                                        1,200 - 2,000 <span class="text-muted">KES</span>
                                    </td>
                                    <td>
                                        <p class="m-0">
                                            <span class="me-2">
                                                
                                                <i class="fas fa-arrow-up text-muted"></i> 
                                                
                                                +5.50%

                                                
                                            </span>

                                        </p>
                                    </td>
                                    <td>
                                        <h5>9,107,193.83 <span class="text-muted">KES</span></h5>
                                        
                                    </td>
                                    <td>
                                        <a href="trade_buy" class="btn btn-sm btn-outline-primary">
                                            <span>BUY</span>
                                            <div class="img" style="background-image: url(user_inner/assets/img/icon.png);"></div>
                                        </a>
                                    </td>
                                </tr>

                                <tr>
                                    <td>
                                        <h6>
                                            <i class="fal fa-user text-muted"></i> 
                                            <a href="user">ForexTrader1</a>
                                        </h6>
                                    </td>
                                    <td>
                                        <h6>M-Pesa</h6>
                                    </td>
                                    <td>
                                        1 hour ago
                                    </td>
                                    <td>
                                        1,200 - 2,000 <span class="text-muted">KES</span>
                                    </td>
                                    <td>
                                        <p class="m-0">
                                            <span class="me-2">
                                                
                                                <i class="fas fa-arrow-up text-muted"></i> 
                                                
                                                +5.50%

                                                
                                            </span>

                                        </p>
                                    </td>
                                    <td>
                                        <h5>9,107,193.83 <span class="text-muted">KES</span></h5>
                                        
                                    </td>
                                    <td>
                                        <a href="trade_buy" class="btn btn-sm btn-outline-primary">
                                            <span>BUY</span>
                                            <div class="img" style="background-image: url(user_inner/assets/img/icon.png);"></div>
                                        </a>
                                    </td>
                                </tr>

                                <tr>
                                    <td>
                                        <h6>
                                            <i class="fal fa-user text-muted"></i> 
                                            <a href="user">ForexTrader1</a>
                                        </h6>
                                    </td>
                                    <td>
                                        <h6>Chipper Cash</h6>
                                    </td>
                                    <td>
                                        1 hour ago
                                    </td>
                                    <td>
                                        1,200 - 2,000 <span class="text-muted">KES</span>
                                    </td>
                                    <td>
                                        <p class="m-0">
                                            <span class="me-2">
                                                
                                                <i class="fas fa-arrow-up text-muted"></i> 
                                                
                                                +5.50%

                                                
                                            </span>

                                        </p>
                                    </td>
                                    <td>
                                        <h5>9,107,193.83 <span class="text-muted">KES</span></h5>
                                        
                                    </td>
                                    <td>
                                        <a href="trade_buy" class="btn btn-sm btn-outline-primary">
                                            <span>BUY</span>
                                            <div class="img" style="background-image: url(user_inner/assets/img/icon.png);"></div>
                                        </a>
                                    </td>
                                </tr>

                                
                                
                            </tbody>
                        </table>

                        <nav aria-label="Pagination">
                            <ul class="pagination pagination-dark">
                                
                                <li class="page-item disabled">
                                    <a class="page-link" href="#" aria-label="Previous">
                                        <span aria-hidden="true">
                                            <i class="fal fa-angle-left"></i>
                                        </span>
                                    </a>
                                </li>
                                
                                <li class="page-item active">
                                    <a class="page-link" href="#">1</a>
                                </li>
                                
                                <li class="page-item">
                                    <a class="page-link" href="#">2</a>
                                </li>
                                
                                <li class="page-item">
                                    <a class="page-link" href="#">3</a>
                                </li>
                                
                                <li class="page-item">
                                    <a class="page-link" href="#" aria-label="Next">
                                        <span aria-hidden="true">
                                            <i class="fal fa-angle-right"></i>
                                        </span>
                                    </a>
                                </li>
                            </ul>
                        </nav>

                    </div>
                    <!-- /right -->
                    
                </div>
                <!-- /row -->
            </div>
            <!-- /card-body -->
        </div>
        <!-- /card -->

    </div>
    <!-- /right_col -->

@endsection