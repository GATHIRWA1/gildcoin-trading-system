@extends('user/layouts/layout_inner')

@section('title', 'Historical Prices')

@section('content')

	<div class="col-md-11 col_chart">

	    <canvas id="historicalPricesChart" class="canvas_world"></canvas>

	    <div class="btn-group btn-group_intervals mt-2" role="group">

	        <input type="radio" class="btn-check" name="btnradio" id="btnradio3" autocomplete="off">
	        <label class="btn btn-outline-secondary" for="btnradio3">1 year</label>

	        <input type="radio" class="btn-check" name="btnradio" id="btnradio4" autocomplete="off">
	        <label class="btn btn-outline-secondary" for="btnradio4">6 months</label>

	        <input type="radio" class="btn-check" name="btnradio" id="btnradio5" autocomplete="off">
	        <label class="btn btn-outline-secondary" for="btnradio5">3 months</label>

	        <input type="radio" class="btn-check" name="btnradio" id="btnradio6" autocomplete="off">
	        <label class="btn btn-outline-secondary" for="btnradio6">2 months</label>

	        <input type="radio" class="btn-check" name="btnradio" id="btnradio7" autocomplete="off" checked>
	        <label class="btn btn-outline-secondary" for="btnradio7">30 days</label>
	        
	    </div>
	    <!-- /btn-group -->

	</div>
	<!-- /right col -->

@endsection

@section('scripts')

        <!-- load ChartJS dist files -->
        <script src="user_inner/assets/js/Chart.min.js"></script>
        
        <!-- Trade Room Chart JS file -->
        <script src="user_inner/assets/js/historicalPricesChart.js"></script>

@endsection