@extends('user/layouts/layout_inner')

@section('title', 'Dashboard')

@section('content')

  <div class="col-md-9 offset-md-1 pt-4">

      <h4 class="mb-4">Dashboard</h4>

      <div class="row row_address">
          <div class="col">
              
              <div class="input-group input-group_address mb-2">

                  <button class="btn btn-outline-secondary" type="button">Gildcoin Address:</button>
                  
                  <input type="text" class="form-control form-control-lg text-light" placeholder="Gildcoin Address" value="1ac824f3152f104bbe7a08b41f85f6592d3c8e909f1552f73cb0sw">
                  
                  <button class="btn btn-outline-primary" type="button">
                      <i class="fal fa-copy"></i> Copy
                  </button>
              </div>

              <p class="text-secondary mb-4">Copy and share to send and receive Gildcoins</p>

          </div>
          <!-- /col -->
      </div>
      <!-- /row -->

      <div class="row row_dash mb-4">
          
          <div class="col-6 col-md-3">
              
              <div class="card card-wallet text-secondary bg-dark border-success mb-3">
              
                  <div class="card-body text-end position-relative">

                      <h1 class="text-secondary position-absolute">
                          <i class="fal fa-wallet"></i>
                      </h1>
                      
                      <a href="wallet" class="link_wallet link-success">
                          <h3 class="card-title">$20,987.00</h3>
                      </a>
                      
                      <p class="card-text">Amount in my wallet</p>
                      
                  </div>
                  <!-- /card-body -->

                  <ul class="list-group list-group-flush">
                      <li class="list-group-item">
                          <a href="#none" data-bs-toggle="modal" data-bs-target="#depositModal" class="link-success">
                              Deposit Funds <i class="fal fa-arrow-right"></i>
                          </a>
                      </li>
                  </ul>
                  <!-- /list-group -->

              </div>
              <!-- /card -->
          </div>
          <!-- /col -->

          <div class="col-6 col-md-3">
              
              <div class="card text-secondary bg-dark mb-3">
              
                  <div class="card-body text-end position-relative">

                      <h1 class="text-secondary position-absolute">
                          <i class="fal fa-coins"></i>
                      </h1>
                      
                      <h3 class="card-title text-white">14.680634</h3>
                      
                      <p class="card-text">Gildcoins</p>
                      
                  </div>
                  <!-- /card-body -->

                  <ul class="list-group list-group-flush">
                      <li class="list-group-item">
                          1 Gildcoin = $5 USD
                      </li>
                  </ul>
                  <!-- /list-group -->

              </div>
              <!-- /card -->
          </div>
          <!-- /col -->

          <div class="col-6 col-md-3">
              
              <div class="card text-secondary bg-dark mb-3">
              
                  <div class="card-body text-end position-relative">

                      <h1 class="text-secondary position-absolute">
                          <i class="fal fa-exchange"></i>
                      </h1>
                      
                      <h3 class="card-title text-white">50</h3>
                      
                      <p class="card-text">Total number of trades</p>
                      
                  </div>
                  <!-- /card-body -->

                  <ul class="list-group list-group-flush">
                      <li class="list-group-item">
                          <a href="trade_room" class="link-secondary">
                              Trade Now <i class="fal fa-arrow-right"></i>
                          </a>
                      </li>
                  </ul>
                  <!-- /list-group -->

              </div>
              <!-- /card -->

          </div>
          <!-- /col -->

          <div class="col-6 col-md-3">
              
              <div class="card text-secondary bg-dark mb-3">
              
                  <div class="card-body text-end position-relative">

                      <h1 class="text-secondary position-absolute">
                          <i class="fal fa-hand-holding-usd"></i>
                      </h1>
                      
                      <h3 class="card-title text-white">$987.00</h3>
                      
                      <p class="card-text">Amount earned</p>
                      
                  </div>
                  <!-- /card-body -->

                  <ul class="list-group list-group-flush">
                      <li class="list-group-item">
                          <a href="trading_history" class="link-secondary">
                              View Trading History <i class="fal fa-arrow-right"></i>
                          </a>
                      </li>
                  </ul>
                  <!-- /list-group -->

              </div>
              <!-- /card -->

          </div>
          <!-- /col -->
      </div>
      <!-- /row_dash -->

      <h5 class="text-white">Gildcoin Statistics / Indicators</h5>

      <div class="row row_graf mb-4">
          
          <div class="col-md-4">
              
              <div class="card text-secondary bg-dark mb-3">

                  <div class="card-body">
                      
                     <div class="row">
                         
                         <div class="col-2">
                              <img src="user_inner/assets/img/icon.png" class="img-fluid" alt=""> 
                         </div>

                         <div class="col-10">
                             xxx
                         </div>

                     </div>

                  </div>
                  <!-- /card-body -->
              </div>
              <!-- /card -->
          </div>
          <!-- /col -->

          <div class="col-md-4">
              
              <div class="card text-secondary bg-dark mb-3">

                  <div class="card-body">
                      
                     <div class="row">
                         
                          <div class="col-2">
                              <img src="user_inner/assets/img/icon.png" class="img-fluid" alt="">
                          </div>

                         <div class="col-10">
                             <p><span class="text-white">$5.00</span> - Buy Price</p>
                             <p><span class="text-white">$4.70</span> - Sell Price</p>
                         </div>

                     </div>

                  </div>
                  <!-- /card-body -->
              </div>
              <!-- /card -->
          </div>
          <!-- /col -->

          <div class="col-md-4">
              
              <div class="card text-secondary bg-dark mb-3">

                  <div class="card-body">
                      
                     <div class="row">
                         
                         <div class="col-2">
                              <img src="user_inner/assets/img/icon.png" class="img-fluid" alt="">
                         </div>

                         <div class="col-10">
                             <p>
                                 <span class="text-white">$11,000,000</span> - Market Capitalisation
                             </p>

                             <p>
                                 <span class="text-white">$580,000</span> - Volume traded daily
                             </p>
                         </div>

                     </div>

                  </div>
                  <!-- /card-body -->
              </div>
              <!-- /card -->
          </div>
          <!-- /col -->


      </div>
      <!-- /row_graf -->

      <div class="row row_news">
          
          <div class="col-md-6">
              
              <div class="card text-secondary bg-dark mb-3">

                  <div class="card-header">
                      <h5 class="text-white my-2 ">
                          <i class="fal fa-chart-line"></i>
                          My Recent Activity
                      </h5>
                  </div>

                  <div class="card-body">
                      
                     zzz

                  </div>
                  <!-- /card-body -->
              </div>
              <!-- /card -->
          </div>
          <!-- /col -->

          <div class="col-md-6">
              
              <div class="card card_news text-secondary bg-dark mb-3">

                  <div class="card-header">
                      <h5 class="text-white my-2">
                          <i class="fal fa-newspaper"></i>
                          Crypto Currency News Feed
                      </h5>
                  </div>

                  <div class="card-body">
                      
                     <ul class="list-unstyled ul_news">
                         
                         <li class="d-flex">
                             <div>
                                 <a href="#none">
                                     <div class="img me-2" style="background-image: url(user_inner/assets/img/thumbs/thumb_01.jpg);"></div>
                                 </a>
                             </div>
                             <div>
                                 <a href="#none">
                                     <h6>Ethereum’s realized cap spikes to record highs as capital floods in: Report</h6>
                                 </a>
                                 <p>By Investing.com - Today at 21:09</p>
                             </div>

                         </li>
                         <!-- /li -->

                         <li class="d-flex">
                             <div>
                                 <a href="#none">
                                     <div class="img me-2" style="background-image: url(user_inner/assets/img/thumbs/thumb_02.jpg);"></div>
                                 </a>
                             </div>
                             <div>
                                 <a href="#none">
                                     <h6>Human Rights Foundation CSO urges Time readers not to 'demonize' Bitcoin</h6>
                                 </a>
                                 <p>By Samuel Gathirwa - Yesterday at 21:09</p>
                             </div>

                         </li>
                         <!-- /li -->

                         <li class="d-flex">
                             <div>
                                 <a href="#none">
                                     <div class="img me-2" style="background-image: url(user_inner/assets/img/thumbs/thumb_03.jpg);"></div>
                                 </a>
                             </div>
                             <div>
                                 <a href="#none">
                                     <h6>Bitcoin Eases as Crypto Market Cap Falls Further Below $1TN, but Demand Remains</h6>
                                 </a>
                                 <p>By Reuters - 26th Jan at 21:09</p>
                             </div>

                         </li>
                         <!-- /li -->

                         <li class="d-flex">
                             <div>
                                 <a href="#none">
                                     <div class="img me-2" style="background-image: url(user_inner/assets/img/thumbs/thumb_04.jpg);"></div>
                                 </a>
                             </div>
                             <div>
                                 <a href="#none">
                                     <h6>Ethereum’s realized cap spikes to record highs as capital floods in: Report</h6>
                                 </a>
                                 <p>By Investing.com - Today at 21:09</p>
                             </div>

                         </li>
                         <!-- /li -->

                         <li class="d-flex">
                             <div>
                                 <a href="#none">
                                     <div class="img me-2" style="background-image: url(user_inner/assets/img/thumbs/thumb.png);"></div>
                                 </a>
                             </div>
                             <div>
                                 <a href="#none">
                                     <h6>Human Rights Foundation CSO urges Time readers not to 'demonize' Bitcoin</h6>
                                 </a>
                                 <p>By Samuel Gathirwa - Yesterday at 21:09</p>
                             </div>

                         </li>
                         <!-- /li -->

                         <li class="d-flex">
                             <div>
                                 <a href="#none">
                                     <div class="img me-2" style="background-image: url(user_inner/assets/img/thumbs/thumb.png);"></div>
                                 </a>
                             </div>
                             <div>
                                 <a href="#none">
                                     <h6>Bitcoin Eases as Crypto Market Cap Falls Further Below $1TN, but Demand Remains</h6>
                                 </a>
                                 <p>By Reuters - 26th Jan at 21:09</p>
                             </div>

                         </li>
                         <!-- /li -->

                     </ul>

                  </div>
                  <!-- /card-body -->
              </div>
              <!-- /card -->
          </div>
          <!-- /col -->


      </div>
      <!-- /row_news -->
  </div>
  <!-- /right col -->

@endsection