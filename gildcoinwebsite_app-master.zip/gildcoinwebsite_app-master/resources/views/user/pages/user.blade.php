@extends('user/layouts/layout_inner')

@section('title', 'Samuel Gathirwa')

@section('content')

	<div class="col-md-9 offset-md-1 pt-4">

        <div class="row row_user_profile">

            <div class="col-md-3">

                <img src="user_inner/assets/img/profile.jpg" alt="" class="img-fluid user_profile mb-4">

                <div class="d-grid mb-3">
                    <a href="#none" class="btn btn-outline-secondary">Send Message</a>
                </div>

                <div class="card card_verification bg-dark mb-4">
                    <div class="card-header">
                        <h5 class="m-0">Verification</h5>
                    </div>
                    <!-- /card-header -->

                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">
                            <i class="fal fa-envelope"></i>
                            <span>Email verified</span>
                        </li>
                        <li class="list-group-item">
                            <i class="fas fa-mobile-alt"></i>
                            <span>Phone verified</span>
                        </li>
                    </ul>
                    
                </div>
                <!-- /card -->

                <div class="card bg-dark mb-4">
                    <div class="card-header">
                        <h5 class="m-0">Info</h5>
                    </div>
                    <!-- /card-header -->

                    <div class="card-body">
                        
                        <table class="table table_user text-light m-0">
                            <tbody>
                                <tr>
                                    <td>Trades</td>
                                    <td>230</td>
                                </tr>
                                <tr>
                                    <td>Blocked by</td>
                                    <td>0</td>
                                </tr>
                                <tr>
                                    <td>Has blocked</td>
                                    <td>0</td>
                                </tr>
                                <tr>
                                    <td>Joined</td>
                                    <td>12 days ago</td>
                                </tr>
                            </tbody>
                        </table>

                    </div>
                    <!-- /card-body -->
                </div>
                <!-- /card -->

            </div>
            <!-- /left -->

            <div class="col-md-9">
                <h2>Barack Obama</h2>
                <p><i class="far fa-eye text-muted"></i> Last seen 23 mins ago</p>


                <div class="d-flex d-flex-feedback mb-4">

                    <div class="card border-success bg-dark">
                        <div class="card-body">
                            <div class="d-flex align-items-center justify-content-between">
                                <h3 class="text-success"><i class="fal fa-thumbs-up"></i></h3>
                                <h3 class="text-success">1,234</h3>
                            </div>
                            <p class="m-0 text-center">Positive Feedback</p>
                        </div>
                    </div>
                    <!-- /card -->

                    <div class="card border-danger bg-dark">
                        <div class="card-body">
                            <div class="d-flex align-items-center justify-content-between">
                                <h3 class="text-danger"><i class="fal fa-thumbs-down"></i></h3>
                                <h3 class="text-danger">12</h3>
                            </div>
                            <p class="m-0 text-center">Negative Feedback</p>
                        </div>
                    </div>
                    <!-- /card -->
                    
                </div>
                <!-- d-flex -->

                <h5>Active Offers</h5>

                <ul class="nav nav-tabs bg-dark">
                    <li class="nav-item">
                        <a href="#none" class="nav-link active">
                            Buy Offers 
                            <span class="badge rounded-pill bg-secondary">23</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#none" class="nav-link">
                            Sell Offers
                            <span class="badge rounded-pill bg-secondary">3</span>
                        </a>
                    </li>
                </ul>

                <div class="nav-tab-content">
                    
                    <p class="my-5 text-center">No active offers found</p>

                </div>
                <!-- /nav-tab-content -->

                <h5>Feedback</h5>

                <ul class="nav nav-tabs bg-dark">
                    <li class="nav-item">
                        <a href="#none" class="nav-link active">
                            From Buyers 
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#none" class="nav-link">
                            From Sellers
                        </a>
                    </li>
                </ul>

                <div class="nav-tab-content">
                    
                    <p class="my-5 text-center">No feedback found</p>

                </div>
                <!-- /nav-tab-content -->

            </div>
            <!-- /right -->
            
        </div>
        <!-- /row -->
        
    </div>
    <!-- /right col -->

@endsection