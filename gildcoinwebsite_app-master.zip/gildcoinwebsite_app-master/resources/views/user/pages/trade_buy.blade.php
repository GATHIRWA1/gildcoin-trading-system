@extends('user/layouts/layout_inner')

@section('title', 'Buy...')

@section('content')

	<div class="col-md-8 offset-md-1">

	    <div class="card bg-dark mt-0 mb-4">
	        
	        <div class="card-body p-5">
	            
	            <h3 class="text-center mb-3">How much do you want to buy?</h3>

	            <form action="trade_started">
	                
	                <div class="row mb-3">
	                
	                    <div class="col-6">
	                        <p class="mb-2">I will pay</p>
	                        <div class="input-group">
	                            <input type="number" name="amount" value="12789.50" class="form-control form-control-lg text-center" required="required">
	                            <span class="input-group-text bg-white">
	                                KES
	                            </span>
	                        </div>
	                    </div>
	                    
	                    <div class="col-6">
	                        <p class="mb-2">and receive</p>

	                        <div class="input-group">
	                            <input type="number" name="crypto" value="0.234567" class="form-control form-control-lg text-center" required="required">
	                            <span class="input-group-text bg-white">GCT</span>
	                        </div>
	                    </div>
	                </div>
	                <!-- /row -->

	                <p><i class="fal fa-info-circle text-muted"></i> You get <strong>9,234.50 KES</strong> worth of Gildcoin</p>

	                <div class="d-grid mb-4">
	                    <button type="submit" name="buy" class="btn btn-primary btn-lg">BUY NOW</button>
	                </div>

	            </form>

	            <p class="text-center mb-0">Reserve Gildcoin for this trade and start a live chat with <a href="user" class="text-decoration-none"> <i class="fal fa-user"></i> DonaldTrump</a></p>

	        </div>
	        <!-- /card-body -->
	    </div>
	    <!-- /card -->

	    <div class="row">
	        
	        <div class="col-md-6">
	            
	            <h5>About this offer</h5>

	            <div class="card bg-dark mt-0 mb-4">

	                <div class="card-body">
	                    xxx
	                </div>
	                
	            </div>
	            <!-- /card -->
	        </div>
	        <!-- /col -->

	        <div class="col-md-6">
	            
	            <h5>About this seller</h5>

	            <div class="card bg-dark mt-0 mb-4">

	                <div class="card-body">
	                    xxx
	                </div>
	                
	            </div>
	            <!-- /card -->
	        </div>
	        <!-- /col -->

	    </div>
	    <!-- /row -->

	    <h5>Offer terms</h5>

	    <div class="card bg-dark mt-0 mb-4">

	        <div class="card-body">
	            xxx
	        </div>
	        
	    </div>

	</div>
	<!-- /right_col -->

@endsection