@extends('user/layouts/layout_inner')

@section('title', 'Account Settings')

@section('content')

	<div class="col-9 offset-1">

	    <div class="card bg-dark text-secondary mt-5">
	        
	        <div class="card-header">
	            <h5 class="text-white my-2">My Account Settings</h5>
	        </div>
	        
	        <div class="card-body">
	            
	            <div class="row row_acc g-0 mt-4">

	                <div class="col-3">
	                    
	                    <div class="nav nav_acc flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
	                
	                        <a class="nav-link active" id="v-pills-profile-tab" data-bs-toggle="pill" href="#v-pills-profile" role="tab" aria-controls="v-pills-profile" aria-selected="true">
	                            <i class="fal fa-user"></i> 
	                            Profile
	                        </a>
	                        
	                        <a class="nav-link" id="v-pills-email-tab" data-bs-toggle="pill" href="#v-pills-email" role="tab" aria-controls="v-pills-email" aria-selected="false">
	                            <i class="fal fa-envelope"></i> 
	                            Contacts
	                        </a>
	                        
	                        <a class="nav-link" id="v-pills-payment-tab" data-bs-toggle="pill" href="#v-pills-payment" role="tab" aria-controls="v-pills-payment" aria-selected="false">
	                            <i class="fal fa-credit-card"></i> 
	                            Payment Methods
	                        </a>
	                        
	                        <a class="nav-link" id="v-pills-password-tab" data-bs-toggle="pill" href="#v-pills-password" role="tab" aria-controls="v-pills-password" aria-selected="false">
	                            <i class="fal fa-unlock-alt"></i> 
	                            Password
	                        </a>
	                    </div>
	                
	                </div>
	                <!-- /col -->

	                <div class="col-9">
	                    
	                    <div class="tab-content tab-content_account p-3" id="v-pills-tabContent">
	                        
	                        <div class="tab-pane fade show active" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
	                            
	                            <form action="">
	                                
	                                <div class="row">

	                                    <div class="col-6">
	                                        <h3 class="text-white">Profile</h3>
	                                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorum sed illum quis unde illo laborum odit, rem facere consequuntur maxime. Exercitationem, voluptatum facilis tenetur ullam iusto assumenda beatae laudantium, animi.</p>
	                                    </div>

	                                    <div class="col-6">

	                                        <label for="firstName" class="form-label text-white">First Name</label>

	                                        <input type="text" name="first_name" class="form-control form-control-lg mb-3" id="firstName" placeholder="First Name" value="Samuel" required="required">

	                                        <label for="lastName" class="form-label text-white">Last Name</label>

	                                        <input type="text" name="last_name" class="form-control form-control-lg mb-3" id="lastName" placeholder="Last Name" value="Gathirwa" required="required">

	                                        <label for="countryResidence" class="form-label text-white">Country of Permanent Residence</label>
	                                        
	                                        <select name="country" class="form-select form-select-lg mb-3" id="countryResidence" required="required">
	                                            <option value="NULL">-</option>
	                                            <option value="1" selected>Kenya</option>
	                                            <option value="2">Tanzania</option>
	                                            <option value="3">Uganda</option>
	                                        </select>

	                                        <button class="btn btn-lg btn-primary float-end" type="submit">
	                                            <i class="fal fa-save"></i> Save
	                                        </button>
	                                    </div>
	                                    
	                                </div>
	                                <!-- /row -->                                                
	                            </form>
	                        </div>
	                        <!-- /tab-pane -->

	                        <div class="tab-pane fade" id="v-pills-email" role="tabpanel" aria-labelledby="v-pills-email-tab">
	                            <div class="row">

	                                <div class="col-6">

	                                    <h3 class="text-white">Contact Details</h3>
	                                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Adipisci cumque ab, consequuntur sequi perferendis, voluptate culpa laboriosam autem totam dolores aut necessitatibus rerum aspernatur placeat, repellendus omnis eum, praesentium? Nobis.</p>
	                                </div>
	                                <!-- /col -->

	                                <div class="col-6">

	                                    <form action="">

	                                        <label for="" class="form-label text-white">Email Address</label>

	                                        <input type="email" name="email" class="form-control form-control-lg mb-3" placeholder="Email Address" value="irungusamuel779@gmail.com" required="required">


	                                        <label class="form-label text-white" for="">Phone Number</label>
	                                        <div class="input-group input-group-phone mb-3">
	                                                                        
	                                            <input name="prefix_country" type="text" class="form-control form-control-lg prefix_country" placeholder="+" value="+254" maxlength="4" required="required">

	                                            <input name="phone_number" type="text" class="form-control form-control-lg phone_number" placeholder="Number" value="719 381888" maxlength="12" required="required">

	                                        </div>
	                                        
	                                        <button class="btn btn-lg btn-primary float-end" type="submit"><i class="fal fa-save"></i> Save</button>

	                                    </form>
	                                </div>
	                                <!-- /col -->
	                            </div>
	                            <!-- /row -->
	                        </div>
	                        <!-- /tab-pane -->

	                        <div class="tab-pane fade" id="v-pills-payment" role="tabpanel" aria-labelledby="v-pills-payment-tab">
	                            <h3 class="text-white">Payment Methods</h3>
	                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. In, eligendi? Dolore laborum a id, molestias deserunt quam, voluptate, consequatur at excepturi dolor fuga ab nihil aspernatur quas porro eaque ea?</p>
	                        </div>
	                        <!-- /tab-pane -->

	                        <div class="tab-pane fade" id="v-pills-password" role="tabpanel" aria-labelledby="v-pills-password-tab">
	                            
	                            <form action="">
	                                <div class="row">

	                                    <div class="col-6">
	                                        
	                                        <h3 class="text-white">Password</h3>
	                                        
	                                        <p>After a successful password update, you will be redirected to the login page where you can log in with your new password.</p>
	                                    </div>

	                                    <div class="col-6 mb-3">
	                                        
	                                        <label for="currentPassword" class="form-label text-white">Current Password</label>
	                                        
	                                        <input type="password" name="current_password" class="form-control form-control-lg" id="currentPassword" placeholder="Current Password" required="required">
	                                        
	                                        <p class="form-text text-muted mb-1">
	                                        Provide your current password in order to change it.
	                                        </p>

	                                        <label for="newPassword" class="form-label text-white">New Password</label>
	                                        
	                                        <input type="password" name="new_password" class="form-control form-control-lg mb-3" id="newPassword" placeholder="New Password" required="required">

	                                        <label for="newPasswordConfirm" class="form-label text-white">New Password Confirmation</label>
	                                        
	                                        <input type="password" name="new_password_confirm" class="form-control form-control-lg" id="newPasswordConfirm" placeholder="Confirm New Password" required="required">

	                                    </div>
	                                </div>
	                                <!-- /row -->

	                                <div class="row">

	                                    <div class="col-12">
	                                        <button class="btn btn-lg btn-primary float-end" type="submit"><i class="fal fa-save"></i> Save Password</button>
	                                    </div>
	                                    
	                                </div>
	                                <!-- /row -->
	                            </form>
	                            
	                        </div>
	                        <!-- /tab-pane -->
	                    </div>
	                    <!-- /tab-content --> 

	                </div>
	                <!-- /col -->
	                
	            </div>
	            <!-- /row -->

	        </div>
	        <!-- /card-body -->
	    </div>
	    <!-- /card -->
	    
	</div>
	<!-- /right col -->

@endsection