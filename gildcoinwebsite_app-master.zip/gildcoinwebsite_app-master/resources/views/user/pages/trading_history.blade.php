@extends('user/layouts/layout_inner')

@section('title', 'Trading History')

@section('content')

	<div class="col-md-9 offset-md-1">

	    <div class="card bg-dark mt-5">
	        
	        <div class="card-header">
	            <h5 class="my-2">My Trading History</h5>
	        </div>
	        <!-- /card-header -->

	        <div class="card-body">
	            
	            <table class="table table_trade_history table-striped table-hover table-sm text-secondary">
	                <thead>
	                    <tr>
	                        <th style="width: 1%;"></th>
	                        <th>Purchase (closing) time</th>
	                        <th>Asset</th>
	                        <th>Investments</th>
	                        <th>Gross P&amp;L</th>
	                        <th>Net P&amp;L</th>
	                        <th>Equity</th>
	                        <th style="width: 1%;"></th>
	                    </tr>
	                </thead>

	                <tbody>
	                    <tr>
	                        <td>
	                            <input type="checkbox" name="">
	                        </td>
	                        <td>
	                            <p>15.01.2021, 00:49:19.043</p>
	                            <p>15.01.2021, 04:51:55.113</p>
	                        </td>
	                        <td>
	                            <p class="fs-5">Gildcoin</p>
	                        </td>
	                        <td>
	                            <p class="fs-5">$40.00</p>
	                        </td>
	                        <td>
	                            <p class="text-success fs-5">$5.20</p>
	                            <p class="text-success"><small>12.99%</small></p>
	                        </td>
	                        <td>
	                            <p class="fs-5">$5.20</p>
	                            <p><small>12.99%</small></p>
	                        </td>
	                        <td>
	                            <p class="fs-5">$45.20</p>
	                        </td>
	                        <td>
	                            <a href="#none" class="btn btn-outline-secondary btn-sm">
	                                <i class="fal fa-angle-down"></i>
	                            </a>
	                        </td>
	                    </tr>
	                    <tr>
	                        <td>
	                            <input type="checkbox" name="">
	                        </td>
	                        <td>
	                            <p>15.01.2021, 00:49:19.043</p>
	                            <p>15.01.2021, 04:51:55.113</p>
	                        </td>
	                        <td>
	                            <p class="fs-5">Gildcoin</p>
	                        </td>
	                        <td>
	                            <p class="fs-5">$40.00</p>
	                        </td>
	                        <td>
	                            <p class="text-success fs-5">$5.20</p>
	                            <p class="text-success"><small>12.99%</small></p>
	                        </td>
	                        <td>
	                            <p class="fs-5">$5.20</p>
	                            <p><small>12.99%</small></p>
	                        </td>
	                        <td>
	                            <p class="fs-5">$45.20</p>
	                        </td>
	                        <td>
	                            <a href="#none" class="btn btn-outline-secondary btn-sm">
	                                <i class="fal fa-angle-down"></i>
	                            </a>
	                        </td>
	                    </tr>
	                    <tr>
	                        <td>
	                            <input type="checkbox" name="">
	                        </td>
	                        <td>
	                            <p>15.01.2021, 00:49:19.043</p>
	                            <p>15.01.2021, 04:51:55.113</p>
	                        </td>
	                        <td>
	                            <p class="fs-5">Gildcoin</p>
	                        </td>
	                        <td>
	                            <p class="fs-5">$40.00</p>
	                        </td>
	                        <td>
	                            <p class="text-success fs-5">$5.20</p>
	                            <p class="text-success"><small>12.99%</small></p>
	                        </td>
	                        <td>
	                            <p class="fs-5">$5.20</p>
	                            <p><small>12.99%</small></p>
	                        </td>
	                        <td>
	                            <p class="fs-5">$45.20</p>
	                        </td>
	                        <td>
	                            <a href="#none" class="btn btn-outline-secondary btn-sm">
	                                <i class="fal fa-angle-down"></i>
	                            </a>
	                        </td>
	                    </tr>
	                    <tr>
	                        <td>
	                            <input type="checkbox" name="">
	                        </td>
	                        <td>
	                            <p>15.01.2021, 00:49:19.043</p>
	                            <p>15.01.2021, 04:51:55.113</p>
	                        </td>
	                        <td>
	                            <p class="fs-5">Gildcoin</p>
	                        </td>
	                        <td>
	                            <p class="fs-5">$40.00</p>
	                        </td>
	                        <td>
	                            <p class="text-danger fs-5">-$5.20</p>
	                            <p class="text-danger"><small>-12.99%</small></p>
	                        </td>
	                        <td>
	                            <p class="fs-5">$5.20</p>
	                            <p><small>12.99%</small></p>
	                        </td>
	                        <td>
	                            <p class="fs-5">$45.20</p>
	                        </td>
	                        <td>
	                            <a href="#none" class="btn btn-outline-secondary btn-sm">
	                                <i class="fal fa-angle-down"></i>
	                            </a>
	                        </td>
	                    </tr>
	                    <tr>
	                        <td>
	                            <input type="checkbox" name="">
	                        </td>
	                        <td>
	                            <p>15.01.2021, 00:49:19.043</p>
	                            <p>15.01.2021, 04:51:55.113</p>
	                        </td>
	                        <td>
	                            <p class="fs-5">Gildcoin</p>
	                        </td>
	                        <td>
	                            <p class="fs-5">$40.00</p>
	                        </td>
	                        <td>
	                            <p class="text-success fs-5">$5.20</p>
	                            <p class="text-success"><small>12.99%</small></p>
	                        </td>
	                        <td>
	                            <p class="fs-5">$5.20</p>
	                            <p><small>12.99%</small></p>
	                        </td>
	                        <td>
	                            <p class="fs-5">$45.20</p>
	                        </td>
	                        <td>
	                            <a href="#none" class="btn btn-outline-secondary btn-sm">
	                                <i class="fal fa-angle-down"></i>
	                            </a>
	                        </td>
	                    </tr>
	                    <tr>
	                        <td>
	                            <input type="checkbox" name="">
	                        </td>
	                        <td>
	                            <p>15.01.2021, 00:49:19.043</p>
	                            <p>15.01.2021, 04:51:55.113</p>
	                        </td>
	                        <td>
	                            <p class="fs-5">Gildcoin</p>
	                        </td>
	                        <td>
	                            <p class="fs-5">$40.00</p>
	                        </td>
	                        <td>
	                            <p class="text-danger fs-5">-$5.20</p>
	                            <p class="text-danger"><small>-12.99%</small></p>
	                        </td>
	                        <td>
	                            <p class="fs-5">$5.20</p>
	                            <p><small>12.99%</small></p>
	                        </td>
	                        <td>
	                            <p class="fs-5">$45.20</p>
	                        </td>
	                        <td>
	                            <a href="#none" class="btn btn-outline-secondary btn-sm">
	                                <i class="fal fa-angle-down"></i>
	                            </a>
	                        </td>
	                    </tr>
	                    <tr>
	                        <td>
	                            <input type="checkbox" name="">
	                        </td>
	                        <td>
	                            <p>15.01.2021, 00:49:19.043</p>
	                            <p>15.01.2021, 04:51:55.113</p>
	                        </td>
	                        <td>
	                            <p class="fs-5">Gildcoin</p>
	                        </td>
	                        <td>
	                            <p class="fs-5">$40.00</p>
	                        </td>
	                        <td>
	                            <p class="text-success fs-5">$5.20</p>
	                            <p class="text-success"><small>12.99%</small></p>
	                        </td>
	                        <td>
	                            <p class="fs-5">$5.20</p>
	                            <p><small>12.99%</small></p>
	                        </td>
	                        <td>
	                            <p class="fs-5">$45.20</p>
	                        </td>
	                        <td>
	                            <a href="#none" class="btn btn-outline-secondary btn-sm">
	                                <i class="fal fa-angle-down"></i>
	                            </a>
	                        </td>
	                    </tr>
	                    <tr>
	                        <td>
	                            <input type="checkbox" name="">
	                        </td>
	                        <td>
	                            <p>15.01.2021, 00:49:19.043</p>
	                            <p>15.01.2021, 04:51:55.113</p>
	                        </td>
	                        <td>
	                            <p class="fs-5">Gildcoin</p>
	                        </td>
	                        <td>
	                            <p class="fs-5">$40.00</p>
	                        </td>
	                        <td>
	                            <p class="text-success fs-5">$5.20</p>
	                            <p class="text-success"><small>12.99%</small></p>
	                        </td>
	                        <td>
	                            <p class="fs-5">$5.20</p>
	                            <p><small>12.99%</small></p>
	                        </td>
	                        <td>
	                            <p class="fs-5">$45.20</p>
	                        </td>
	                        <td>
	                            <a href="#none" class="btn btn-outline-secondary btn-sm">
	                                <i class="fal fa-angle-down"></i>
	                            </a>
	                        </td>
	                    </tr>
	                    <tr>
	                        <td>
	                            <input type="checkbox" name="">
	                        </td>
	                        <td>
	                            <p>15.01.2021, 00:49:19.043</p>
	                            <p>15.01.2021, 04:51:55.113</p>
	                        </td>
	                        <td>
	                            <p class="fs-5">Gildcoin</p>
	                        </td>
	                        <td>
	                            <p class="fs-5">$40.00</p>
	                        </td>
	                        <td>
	                            <p class="text-success fs-5">$5.20</p>
	                            <p class="text-success"><small>12.99%</small></p>
	                        </td>
	                        <td>
	                            <p class="fs-5">$5.20</p>
	                            <p><small>12.99%</small></p>
	                        </td>
	                        <td>
	                            <p class="fs-5">$45.20</p>
	                        </td>
	                        <td>
	                            <a href="#none" class="btn btn-outline-secondary btn-sm">
	                                <i class="fal fa-angle-down"></i>
	                            </a>
	                        </td>
	                    </tr>
	                    <tr>
	                        <td>
	                            <input type="checkbox" name="">
	                        </td>
	                        <td>
	                            <p>15.01.2021, 00:49:19.043</p>
	                            <p>15.01.2021, 04:51:55.113</p>
	                        </td>
	                        <td>
	                            <p class="fs-5">Gildcoin</p>
	                        </td>
	                        <td>
	                            <p class="fs-5">$40.00</p>
	                        </td>
	                        <td>
	                            <p class="text-success fs-5">$5.20</p>
	                            <p class="text-success"><small>12.99%</small></p>
	                        </td>
	                        <td>
	                            <p class="fs-5">$5.20</p>
	                            <p><small>12.99%</small></p>
	                        </td>
	                        <td>
	                            <p class="fs-5">$45.20</p>
	                        </td>
	                        <td>
	                            <a href="#none" class="btn btn-outline-secondary btn-sm">
	                                <i class="fal fa-angle-down"></i>
	                            </a>
	                        </td>
	                    </tr>
	                    
	                </tbody>
	            </table>

	            <nav>
	                <ul class="pagination justify-content-end">
	                    <li class="page-item disabled">
	                        <a class="page-link" href="#none" tabindex="-1" aria-disabled="true">
	                            &lt;
	                        </a>
	                    </li>
	                    
	                    <li class="page-item"><a class="page-link" href="#none">1</a></li>
	                    
	                    <li class="page-item"><a class="page-link" href="#none">2</a></li>
	                    
	                    <li class="page-item"><a class="page-link" href="#none">3</a></li>
	                    
	                    <li class="page-item">
	                        <a class="page-link" href="#none">
	                            &gt;
	                        </a>
	                    </li>
	                </ul>
	            </nav>

	        </div>
	    </div>
	    <!-- /card -->
	    
	</div>
	<!-- /right col -->

@endsection