<div class="modal modal_cancel_trade fade" id="cancelTradeModal" tabindex="-1" aria-labelledby="cancelTradeModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            
            <div class="modal-header">
                
                <h5 class="modal-title" id="cancelTradeModalLabel">
                    Hold On
                </h5>
                
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <form action="" method="post">
            
                <div class="modal-body">

                    <div class="alert alert-danger" role="alert">
                        <i class="far fa-info-circle"></i> Stay on this trade if you've already made this payment. For any other issues, click <strong>Back</strong> and start a dispute.
                    </div>
                    
                    <div class="form-check">
                        
                        <input class="form-check-input" type="checkbox" name="confirm_cancel" id="checkboxConfirm">
                        
                        <label class="form-check-label" for="checkboxConfirm">I confirm that <strong>I have not paid</strong> on this trade and I want to cancel.</label>
                    </div>

                </div>
                
                <div class="modal-footer d-flex justify-content-between">
                    
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                        Back
                    </button>
                    
                    <button type="submit" name="cancel_trade" class="btn btn-danger">Cancel Trade</button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- /cancelTradeModal -->